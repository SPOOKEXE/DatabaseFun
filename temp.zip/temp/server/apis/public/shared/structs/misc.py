
from pydantic import BaseModel
