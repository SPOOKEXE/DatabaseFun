
class Gender:
	MALE = (0, 'MALE')
	FEMALE = (1, 'FEMALE')

class GeographicLocations:
	AUSTRALIA = (0, 'AUSTRALIA')

class Languages:
	ENGLISH = (0, 'English')

class NotificationLevel:
	ALL = (0, 'All')
	NONE = (1, 'None')
